export const VITE_REACT_APP_BASE_URL = "/api/v1";
